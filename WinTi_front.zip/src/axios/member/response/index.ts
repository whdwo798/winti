import ResponseDto from "./respons.dto";

export type { ResponseDto };
