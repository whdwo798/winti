import ResponseDto from "../respons.dto";


export default interface FindIdResponseDto extends ResponseDto{

    userIds : string[];
}