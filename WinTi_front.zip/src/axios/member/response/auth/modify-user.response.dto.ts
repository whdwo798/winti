import ResponseDto from "../respons.dto";

export default interface ModifyUserResponseDto extends ResponseDto {
    
}