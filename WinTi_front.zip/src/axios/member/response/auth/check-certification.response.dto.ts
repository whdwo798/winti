import ResponseDto from "../respons.dto";

export default interface CheckCertificationResponseDto extends ResponseDto {
    
}