import ResponseDto from "../respons.dto";

export default interface DisableUserResponseDto extends ResponseDto {
    
}