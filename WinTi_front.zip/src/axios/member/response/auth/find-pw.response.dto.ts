import ResponseDto from "../respons.dto";

export default interface FindPwResponseDto extends ResponseDto {
    
}