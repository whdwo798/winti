import ResponseDto from "../respons.dto";

export default interface EmailCertificationResponseDto extends ResponseDto {
    
}