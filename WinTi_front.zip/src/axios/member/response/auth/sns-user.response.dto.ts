import ResponseDto from "../respons.dto";

export default interface SnsUserResponseDto extends ResponseDto {


}