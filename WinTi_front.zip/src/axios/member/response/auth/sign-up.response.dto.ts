import ResponseDto from "../respons.dto";

export default interface SignUpResponseDto extends ResponseDto {


}