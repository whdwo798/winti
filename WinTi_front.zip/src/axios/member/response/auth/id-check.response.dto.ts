import ResponseDto from "../respons.dto";

export default interface IdCheckResponseDto extends ResponseDto{


}