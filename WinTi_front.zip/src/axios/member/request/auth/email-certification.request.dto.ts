export default interface EmailCertificationRequestDto {
    id : string;
    email : string;
}