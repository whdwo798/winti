export default interface FindUserRequestDto {

token : string;

}