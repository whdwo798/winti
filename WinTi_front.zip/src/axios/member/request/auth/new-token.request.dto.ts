export default interface NewTokenRequestDto{
    
    userId : string;
    refreshTokenwoo : string;

}