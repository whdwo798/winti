export default interface IdCheckRequestDto{
    id: string;

}