export default interface ModifyUserRequestDto{
    
    id : string;
    password? : string;
    address? : string;
    subaddress? : string;

}