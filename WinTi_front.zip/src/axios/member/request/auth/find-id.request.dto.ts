export default interface FindIdRequestDto {

    username : string;

    email : string ;
}