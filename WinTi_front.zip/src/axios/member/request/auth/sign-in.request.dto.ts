export default interface SignInRequestDto {

    id : string;
    password: string;

}