export default interface DisableUserRequestDto {

    userId: string;

}