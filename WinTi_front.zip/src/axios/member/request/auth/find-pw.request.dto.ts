export default interface FindPwRequestDto{

    id : string ;
    email : string ;

}