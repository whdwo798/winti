import React from 'react'
import CategoryPage from '../../components/category/CategoryPage'

const Category = () => {
        return (
                <div className='contWrap'>
                        <CategoryPage />
                </div>
        )
}

export default Category
