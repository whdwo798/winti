import React from 'react'
import SearchPage from '../../components/Search/SearchPage'

const Serach = () => {
    return (
<<<<<<< HEAD
        <div className='contWrap'>
=======
<<<<<<< HEAD
        <div className='contWrap'>
=======
        <div>
>>>>>>> f48e37652b587dea6a28be65b2420a180ed79438
>>>>>>> be0c1710ce7b6c1acead5ac1a35bf1019b46d514
            <SearchPage />
        </div>
    )
}

export default Serach