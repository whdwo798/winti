package com.winti.backend.member.dto.response.auth;

public class DeleteSnsUserRequestDto {


}
