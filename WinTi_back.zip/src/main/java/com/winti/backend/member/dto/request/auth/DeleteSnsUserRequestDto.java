package com.winti.backend.member.dto.request.auth;

public class DeleteSnsUserRequestDto {
}
