package com.winti.backend.show.payment.exception;

public class PaymentMismatchException extends Exception {
    public PaymentMismatchException(String message) {
        super(message);
    }
}