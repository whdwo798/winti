package com.winti.backend.show.payment.exception;

public class PaymentVerificationException extends RuntimeException{
    public PaymentVerificationException(String message){
        super(message);
    }
}
