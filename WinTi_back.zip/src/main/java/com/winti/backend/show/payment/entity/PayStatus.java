package com.winti.backend.show.payment.entity;

public enum PayStatus {

    OK,
    READY,
}
